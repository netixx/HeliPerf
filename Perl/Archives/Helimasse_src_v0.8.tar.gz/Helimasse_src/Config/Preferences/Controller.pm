package Config::Preferences::Controller;

use strict;

1;