package prefWin::ControllerInit;

use strict;

use prefWin::Controller;

use Exporter;
our @ISA=qw(Exporter);
our @EXPORT=qw();#exportation des variables pour que les fonctions puissent être appelées par le programme (limitation glade)importer &exporter &modifier);#exportation des variables pour que les fonctions puissent être appelées par le programme (limitation glade)

1;