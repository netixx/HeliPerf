package models::CarburantItem;

use base
