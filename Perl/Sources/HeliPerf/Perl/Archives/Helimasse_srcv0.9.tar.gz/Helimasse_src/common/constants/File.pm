#package constants::File;
#
#use Exporter;
#our @ISA=qw(Exporter);
#our @EXPORT=qw(HELICO_FILE EDIT_FILE PROFILS_FILE CARBURANT_FILE);

use constant EDITEUR_FILE => 'editeur.dat';
use constant HELICO_FILE => 'helico.dat';
use constant CONFIG_FILE => 'config.dat';
use constant CARBURANT_FILE => 'carburant.dat';
use constant PROFILS_FILE => 'profils.dat';

1;
